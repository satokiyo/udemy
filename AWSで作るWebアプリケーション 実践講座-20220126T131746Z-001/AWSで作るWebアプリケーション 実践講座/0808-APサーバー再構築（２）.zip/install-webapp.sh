#!/bin/bash
# ---------------------------------
# Install Node.js application
# ---------------------------------
mkdir tastylog
tar -zxvf ./tastylog-app-1.8.1.tar.gz -C tastylog
sudo mv ./tastylog/ /opt/
