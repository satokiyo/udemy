#! /bin/sh

env

exec "$@"