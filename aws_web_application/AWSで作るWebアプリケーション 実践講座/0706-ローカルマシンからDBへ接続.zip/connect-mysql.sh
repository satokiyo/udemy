#!/bin/bash
mysql -u<USER> -p<PASSWORD> -h<HOST> -P<PORT>
