#!/bin/bash
ssh -i <KEYFILE> \
    -NL <LOCAL_PORT>:<DB_HOST>:<DB_PORT> \
    ec2-user@<PUBLIC_IP>
