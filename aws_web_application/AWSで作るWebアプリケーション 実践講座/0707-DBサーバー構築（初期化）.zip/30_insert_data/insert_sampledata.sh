#!/bin/bash

mysql --defaults-extra-file=../dbaccess.cnf < ./m_address.sql
mysql --defaults-extra-file=../dbaccess.cnf < ./m_category.sql
mysql --defaults-extra-file=../dbaccess.cnf < ./t_user.sql
mysql --defaults-extra-file=../dbaccess.cnf < ./t_shop.sql
mysql --defaults-extra-file=../dbaccess.cnf < ./t_review.sql
mysql --defaults-extra-file=../dbaccess.cnf < ./t_shop_category.sql
