db.posts.drop();
db.users.drop();
db.privileges.drop();
